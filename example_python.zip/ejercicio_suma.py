# ejercicio sumar dos numeros

#entrada
num1 = 6
num2 = 3

#proceso
suma = num1 + num2

#salida
print(suma)

""" comentarios de varios renglones"""
# comentarios en un solo renglon

#ejercicio restar dos numeros

#proceso
resta= num1 - num2

#salida
print(resta)
