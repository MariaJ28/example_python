#entrada
num1=2
num2=5

#proceso
multiplicacion = num1 * num2

#salida
print(multiplicacion)