"""
#cajero automatico
cuenta="el numero de cuenta es:"
numero_cuenta = 97835698454

clave="la clave es:"
clave_cuenta = 4567

saldo="el saldo de la cuenta es:"
saldo_cuenta =800000

monto="el valor a retirar es:"
monto_retiro = 300000

restante="el saldo restante de la cuenta es:"
saldo_restante=saldo_cuenta - monto_retiro

print(cuenta)
print(numero_cuenta)
print(clave) 
print(clave_cuenta)
print(saldo) 
print(saldo_cuenta)
print(monto) 
print(monto_retiro)
print(restante) 
print(saldo_restante) 
"""

"""
#usar un chat
contacto="el nombre del contacto es:"
nombre_usuario="Maria Jose"

conexion="el estado de conexion es:"
estado="en linea"

tiempo="la fecha y hora en que se envio el mensaje fue:"
fecha="21/02/2023"
hora= "10:47 a.m"

envio="el mensaje enviado fue:"
mensaje="hola,como estas?"

print(contacto)
print(nombre_usuario)
print(conexion)
print(estado)
print(tiempo)
print(fecha)
print(hora)
print(envio)
print(mensaje)
"""
"""
#pagar con tarjeta de credito
cuenta="el numero de la cuenta es"
numero_cuenta=96474896

saldo="el saldo disponible es:"
saldo_disponible=1000000

valor="el valor a pagar por el producto es:"
valor_producto=5000

restante="el saldo restante en la tarjeta es:"
saldo_restante=(saldo_disponible -valor_producto)

print(cuenta)
print(numero_cuenta)
print(saldo)
print(saldo_disponible)
print(valor)
print(valor_producto)
print(restante)
print(saldo_restante)
"""
"""
#lavar ropa

lav="vas a usar lavadora?"
lavadora=True

tie="cual va a ser el tiempo de lavado?"
tiempo = "30 min"

ropa="que cantidad de ropa se va a lavar?"
cantida_ropa= 15

producto="que producto va a utilizar ?"
tipo_producto= "detergente"

agua="que cantidad de agua va a utilizar?"
cantidad_agua=10.0

print(lav)
print(lavadora)
print(tie)
print(tiempo)
print(ropa)
print(cantida_ropa)
print(producto)
print(tipo_producto)
print(agua)
print(cantidad_agua)
"""

#hablar por telefono
"""
metodo="por que medio haras la llamada?"
metodo_llamada="celular"

saldo="tienes saldo?"
saldo_telefono=True

disponible="esta disponible el contacto?"
disponibilidad="disponible"

numero="cual es el numero del contacto?"
numero_contacto=3005658472

print(metodo)
print(metodo_llamada)
print(saldo)
print(saldo_telefono)
print(disponible)
print(disponibilidad)
print(numero)
print(numero_contacto)
"""





