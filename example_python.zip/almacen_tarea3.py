zapatos="el precio de los zapatos es:"
zapatos1=350000

tenis="el precio de los tenis es:"
tenis1=280000

camisetas="el precio de las camisas es:"
camisetas1=175000

jeans="el precio de los jeans es:"
jeans1=200000

costo="el costo total de los articulos es:"
costo_total= zapatos1 + tenis1 +camisetas1 +jeans1

promedio="el promedio de las ventas es:"
promedio_venta= costo_total/4

nuevo_precio="el nuevo precio de jeans con el aumento del 6.2% es de:"
aumento_jeans=jeans1+(jeans1*0.062)

precio_nuevo="el nuevo precio de los zapatos al disminuir el o.8% es de:"
disminucion_zapatos=zapatos1-(zapatos1*0.008)

print(zapatos)
print(zapatos1)
print(tenis)
print(tenis1)
print(camisetas)
print(camisetas1)
print(jeans)
print(jeans1)
print(costo)
print(costo_total)
print(promedio)
print(promedio_venta)
print(nuevo_precio)
print(aumento_jeans)
print(precio_nuevo)
print(disminucion_zapatos)